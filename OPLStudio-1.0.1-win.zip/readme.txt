OPL Studio v1.0.1

This zip file contains the OPL Studio software for Teensy 3.6 / Teensy 4.1 and the TyUploader to upload the software to your OPL Studio.

To upload the software run TyUploader from the archive. When you have your OPL Studio connected you should find ‘OPL Studio’ in the list of connected devices. Click the Upload button and select the .hex file that is appropriate for your Teensy: the ‘_T36’ file for a Teensy 3.6 or the ‘_T41’ file for a Teensy 4.1. After selecting the file uploading will begin.

During software update the power LED of OPL Studio will faintly glow. After updating the software, OPL Studio will reboot. The new software version will be shown in the bottom left corner of the boot screen or you can find it in the about screen in the OPL Studio settings. If this is the first time the OPL Studio software is installed on your Teensy then OPL Studio will boot into the pointer calibration, otherwise it will boot directly to the home screen. You may want to do a factory reset on OPL Studio in case you used your Teensy for another project before.

In case of any issues please see the OPL Studio manual that can be downloaded from www.cheerfu.nl

For more info about TyUploader or other supported platforms visit https://github.com/Koromix/tytools
